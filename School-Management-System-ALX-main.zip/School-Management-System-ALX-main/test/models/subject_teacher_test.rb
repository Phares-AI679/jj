require "test_helper"

class SubjectTeacherTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
