import { Grid } from '@material-ui/core'
import React from 'react'
import Dashboard from './Dashboard/Dashboard'






 



function AdminView() {
  
  return (
    <>
      {/* <div>This will be the Admin's view after Logging in</div> */}
      {/* <Adminbar /> */}
      {/* <StudentForm/> */}
      <Dashboard/>
    </>

  )
}

export default AdminView