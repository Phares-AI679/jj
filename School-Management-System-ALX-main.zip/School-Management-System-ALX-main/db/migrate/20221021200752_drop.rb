class Drop < ActiveRecord::Migration[7.0]
  def change
  end
end
