class Assignment < ApplicationRecord
      belongs_to :subject
end
