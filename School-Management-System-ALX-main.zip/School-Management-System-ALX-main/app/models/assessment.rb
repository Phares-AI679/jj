class Assessment < ApplicationRecord
      belongs_to :subject
end
