class Staff < ApplicationRecord
end
