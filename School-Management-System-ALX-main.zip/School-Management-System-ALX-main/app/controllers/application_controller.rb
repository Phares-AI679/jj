class ApplicationController < ActionController::API
    include ActionController::Cookies


end
